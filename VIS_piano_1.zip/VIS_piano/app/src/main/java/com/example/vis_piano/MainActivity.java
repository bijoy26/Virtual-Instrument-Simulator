package com.example.vis_piano;

import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
   private SoundPool soundPool;
    private int a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        soundPool = new SoundPool.Builder().setMaxStreams(5).build();


        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){

            soundPool = new SoundPool.Builder().setMaxStreams(5).build();
        }
        else {
            soundPool = new SoundPool(5, AudioManager.STREAM_MUSIC,0);

        }
        a1 = soundPool.load(this, R.raw.a3);
        a2 = soundPool.load(this, R.raw.a);
        a3 = soundPool.load(this, R.raw.a3);
        a4 = soundPool.load(this, R.raw.a3);
        a5 = soundPool.load(this, R.raw.a3);
        a6 = soundPool.load(this, R.raw.a3);
        a7 = soundPool.load(this, R.raw.a3);
        a8 = soundPool.load(this, R.raw.a3);
        a9 = soundPool.load(this, R.raw.a3);
        a10 = soundPool.load(this, R.raw.a3);
        a11 = soundPool.load(this, R.raw.a3);
        a12 = soundPool.load(this, R.raw.a3);




    }
}

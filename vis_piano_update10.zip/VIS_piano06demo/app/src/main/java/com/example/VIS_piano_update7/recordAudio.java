package com.example.VIS_piano_update7;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.VIS_piano_update8.R;

import java.io.File;
import java.io.IOException;
import java.util.UUID;


public class recordAudio extends AppCompatActivity {

    Button Btn1;
    private AlertDialog.Builder alertdialogbuilder2;


    String pathSave = null;
    MediaRecorder mediaRecorder= null;
    MediaPlayer mediaPlayer = null;

    final String newFolderName = "Recorder Library";

    private static final String LOG_TAG = "errorTAG";  //LOG_TAG is used for log errors

    ImageButton btnImgRec,btnImgStopRec,btnImgPlay,btnImgStop;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_audio);

        Btn1=findViewById(R.id.exit3);

        btnImgRec =  findViewById(R.id.btnRecord);
        btnImgStopRec = findViewById(R.id.btnStpRec);
        btnImgPlay =  findViewById(R.id.btnPlay);
        btnImgStop =  findViewById(R.id.btnStop);

        btnImgRec.setEnabled(true);
        btnImgStopRec.setEnabled(false);
        btnImgPlay.setEnabled(false);
        btnImgStop.setEnabled(false);

        final File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),newFolderName); //creates new file named 'newFolderName'

        if(!file.exists()) {
            file.mkdirs();   //create folder
            Log.d("Directory","New directory created in" + file.getAbsolutePath());    // file.getAbsolutePath() returns the path of the folder that it points to
        }

        Btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertdialogbuilder2 = new AlertDialog.Builder(recordAudio.this);
                alertdialogbuilder2.setTitle("Exit");
                alertdialogbuilder2.setMessage("Do u want to go back to piano?");
                alertdialogbuilder2.setIcon(R.drawable.question);
                alertdialogbuilder2.setPositiveButton("yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        Intent intent3=new Intent(recordAudio.this,MainActivity.class);
                        startActivity(intent3);
                    }

                });
                alertdialogbuilder2.setNegativeButton("no", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        dialogInterface.cancel();
                    }
                });


                AlertDialog alertDialog = alertdialogbuilder2.create();
                alertDialog.show();
            }
        });


        btnImgRec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //  pathSave = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + File.separatorChar + UUID.randomUUID().toString() + "audio_record.3gp";
                //pathSave = Environment.getExternalStorageDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + File.separatorChar + UUID.randomUUID().toString() + "_audio_record.3gp";  // SUGGESTED FROM DEVELOPER
                pathSave = file.getAbsolutePath() + File.separatorChar + UUID.randomUUID().toString() + "audio_record.3gp";

                Log.d("PathCheck",pathSave); //Log for check path
                setupMediaRecorder();

                try {
                    mediaRecorder.prepare();
                    mediaRecorder.start();
                } catch (IOException ioe) {
                    // ioe.printStackTrace();
                    Log.e(LOG_TAG,"MediaRecorder prepare() Or start() Failed");
                }
                btnImgStopRec.setEnabled(true);
                btnImgStop.setEnabled(false);
                btnImgPlay.setEnabled(false);
                btnImgRec.setEnabled(false);
                Toast.makeText(recordAudio.this,"Recording...", Toast.LENGTH_SHORT).show();
            }
        });

        btnImgStopRec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mediaRecorder.stop();
                mediaRecorder.release(); // added later
                mediaRecorder = null;  //added later
                //  mediaRecorder.reset();

                //  mediaRecorder=null; //  added later

                btnImgStop.setEnabled(false);
                btnImgStopRec.setEnabled(false);
                btnImgPlay.setEnabled(true);
                btnImgRec.setEnabled(true);

                Toast.makeText(recordAudio.this,"Record finished!", Toast.LENGTH_SHORT).show();
            }
        });

        btnImgPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (mediaPlayer == null) {

                    btnImgStop.setEnabled(true);
                    btnImgRec.setEnabled(false);
                    btnImgPlay.setEnabled(false);
                    btnImgStopRec.setEnabled(false);

                    mediaPlayer = new MediaPlayer();

                    try {
                        mediaPlayer.setDataSource(pathSave);
                        mediaPlayer.prepare();
                    } catch (IOException e) {
                        Log.e(LOG_TAG, e.getMessage());
                    }

                    Toast.makeText(recordAudio.this, "Playing...", Toast.LENGTH_SHORT).show();

                    mediaPlayer.start();

                    mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {   //when record auto completes Stop() method is called
                        @Override
                        public void onCompletion(MediaPlayer mediaPlayer) {
                            StopPlayer(); //function call to stop recording
                        }
                    });

                }
            }
        });

        btnImgStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StopPlayer();
            }
        });
    }


    private void StopPlayer(){      // Stopplayer() is private (internally called) and doesn't need view as argument

        try {
            if(mediaPlayer != null){

                btnImgStopRec.setEnabled(false);
                btnImgStop.setEnabled(false);
                btnImgRec.setEnabled(true);
                btnImgPlay.setEnabled(true);

                mediaPlayer.stop();

                Toast.makeText(recordAudio.this,"Stopped", Toast.LENGTH_SHORT).show();
                mediaPlayer.release();  //space release when object is not in need anymore
                mediaPlayer = null;     //setting object null so that it can be initialized again when needed

            }
        } catch (Exception ioe)
        {
            ioe.printStackTrace();
        }
    }

    public void setupMediaRecorder()
    {
        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        mediaRecorder.setOutputFile(pathSave);

    }

    @Override
    public void onStop(){   // Deallocating memory when application stops
        super.onStop();
        if(mediaRecorder != null ) {
            mediaRecorder.release();
            mediaRecorder = null;
        }
        if(mediaPlayer != null){
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}

package com.example.vis_piano;

import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

   private SoundPool soundPool;   //Soundpool library for audio processing

   private int a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13;  //for 1 octave only
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        soundPool = new SoundPool.Builder().setMaxStreams(5).build();


        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){

            soundPool = new SoundPool.Builder().setMaxStreams(5).build();
        }
        else {
            soundPool = new SoundPool(5, AudioManager.STREAM_MUSIC,0);

        }


        a1 = soundPool.load(this,R.raw.a_3,1);   // assigning resource audio to each variable
        a2 = soundPool.load(this,R.raw.a_sharp_3,1);
        a3 = soundPool.load(this,R.raw.b_3,1);
        a4 = soundPool.load(this,R.raw.c_3,1);
        a5 = soundPool.load(this,R.raw.c_sharp_3,1);
        a6 = soundPool.load(this,R.raw.d_3,1);
        a7 = soundPool.load(this,R.raw.d_sharp_3,1);
        a8 = soundPool.load(this,R.raw.e_3,1);
        a9 = soundPool.load(this,R.raw.f_3,1);
        a10 = soundPool.load(this,R.raw.f_sharp_3,1);
        a11 = soundPool.load(this,R.raw.g_3,1);
        a12 = soundPool.load(this,R.raw.g_sharp_3,1);
        a13 = soundPool.load(this,R.raw.a4,1);
    }
    public void click(View view){

        switch (view.getId()){
            case R.id.wbtn1:
                soundPool.play(a4,1,1,0,0,1);
                break;
            case R.id.wbtn2:
                soundPool.play(a6,1,1,0,0,1);
                break;

            case R.id.wbtn3:
                soundPool.play(a8,1,1,0,0,1);
                break;

            case R.id.wbtn4:
                soundPool.play(a9,1,1,0,0,1);
                break;

            case R.id.wbtn5:
                soundPool.play(a11,1,1,0,0,1);
                break;
            case R.id.wbtn6:
                soundPool.play(a13,1,1,0,0,1);
                break;

            case R.id.wbtn7:
                break;

        }
    }
}

package com.example.VIS_piano_update7;

import android.content.DialogInterface;
import android.content.Intent;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.VIS_piano_update8.R;

public class MainActivity extends AppCompatActivity  {

    private SoundPool soundPool;   //Soundpool library for audio processing
    private Button exitBtn,heplbtn;

    private AlertDialog.Builder alert_dialogbuilder;

    private int notes[] = new int[25];  // Array containing 2 Octave piano notes (C3-C5)
 //   private int a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13;  //for 1 octave only

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        exitBtn = findViewById(R.id.exbtn);

        soundPool = new SoundPool.Builder().setMaxStreams(5).build();


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            soundPool = new SoundPool.Builder().setMaxStreams(5).build();
        } else {
            soundPool = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);

        }

        notes[1] = soundPool.load(this, R.raw.c_3, 1);   // assigning resource audio to each variable of notes[]
        notes[2] = soundPool.load(this, R.raw.c_sharp_3, 1);
        notes[3] = soundPool.load(this, R.raw.d_3, 1);
        notes[4] = soundPool.load(this, R.raw.d_sharp_3, 1);
        notes[5] = soundPool.load(this, R.raw.e_3, 1);
        notes[6] = soundPool.load(this, R.raw.f_3, 1);
        notes[7] = soundPool.load(this, R.raw.f_sharp_3, 1);
        notes[8] = soundPool.load(this, R.raw.g_3, 1);
        notes[9] = soundPool.load(this, R.raw.g_sharp_3, 1);
        notes[10] = soundPool.load(this, R.raw.a_3, 1);
        notes[11] = soundPool.load(this, R.raw.a_sharp_3, 1);
        notes[12] = soundPool.load(this, R.raw.b_3, 1);
        notes[13] = soundPool.load(this, R.raw.c_4, 1);

        notes[14] = soundPool.load(this, R.raw.c_sharp_4, 1);
        notes[15] = soundPool.load(this, R.raw.d_4, 1);
        notes[16] = soundPool.load(this, R.raw.d_sharp_4, 1);
        notes[17] = soundPool.load(this, R.raw.e_4, 1);
        notes[18] = soundPool.load(this, R.raw.f_4, 1);
        notes[19] = soundPool.load(this, R.raw.f_sharp_4, 1);
        notes[20] = soundPool.load(this, R.raw.g_4, 1);
        notes[21] = soundPool.load(this, R.raw.g_sharp_4, 1);
        notes[22] = soundPool.load(this, R.raw.a_4, 1);
        notes[23] = soundPool.load(this, R.raw.a_sharp_4, 1);
        notes[24] = soundPool.load(this, R.raw.b_4, 1);

    }

    public void click(View view) {

        switch (view.getId()) {

            /* White Buttons*/

            case R.id.wbtn1:
                soundPool.play(notes[1], 1, 1, 0, 0, 1);
                break;
            case R.id.wbtn2:
                soundPool.play(notes[3], 1, 1, 0, 0, 1);
                break;

            case R.id.wbtn3:
                soundPool.play(notes[5], 1, 1, 0, 0, 1);
                break;

            case R.id.wbtn4:
                soundPool.play(notes[6], 1, 1, 0, 0, 1);
                break;

            case R.id.wbtn5:
                soundPool.play(notes[8], 1, 1, 0, 0, 1);
                break;
            case R.id.wbtn6:
                soundPool.play(notes[10], 1, 1, 0, 0, 1);
                break;

            case R.id.wbtn7:
                soundPool.play(notes[12],1,1,0,0,1);
                break;

            case R.id.wbtn8:
                soundPool.play(notes[13], 1, 1, 0, 0, 1);
                break;
            case R.id.wbtn9:
                soundPool.play(notes[15], 1, 1, 0, 0, 1);
                break;

            case R.id.wbtn10:
                soundPool.play(notes[17], 1, 1, 0, 0, 1);
                break;

            case R.id.wbtn11:
                soundPool.play(notes[18], 1, 1, 0, 0, 1);
                break;

            case R.id.wbtn12:
                soundPool.play(notes[20], 1, 1, 0, 0, 1);
                break;
            case R.id.wbtn13:
                soundPool.play(notes[22], 1, 1, 0, 0, 1);
                break;
            case R.id.wbtn14:
                soundPool.play(notes[24],1,1,0,0,1);
                break;



            /* BLACK BUTTONS TESTING START HERE */
            case R.id.blk1:
                soundPool.play(notes[2], 1, 1, 0, 0, 1);
                break;
            case R.id.blk2:
                soundPool.play(notes[4], 1, 1, 0, 0, 1);
                break;

            case R.id.blk3:
                soundPool.play(notes[7], 1, 1, 0, 0, 1);
                break;

            case R.id.blk4:
                soundPool.play(notes[9], 1, 1, 0, 0, 1);
                break;

            case R.id.blk5:
                soundPool.play(notes[11],1,1,0,0,1);
                break;


            case R.id.blk6:
                soundPool.play(notes[14], 1, 1, 0, 0, 1);
                break;
            case R.id.blk7:
                soundPool.play(notes[16], 1, 1, 0, 0, 1);
                break;

            case R.id.blk8:
                soundPool.play(notes[19], 1, 1, 0, 0, 1);
                break;

            case R.id.blk9:
                soundPool.play(notes[21], 1, 1, 0, 0, 1);
                break;

            case R.id.blk10:
              soundPool.play(notes[23],1,1,0,0,1);
                break;

            case R.id.help:
                Intent intent=new Intent(MainActivity.this,help.class);
                startActivity(intent);
            default:
                    break;
        }
    }



    public void ExitClick(View view) {


        switch (view.getId()) {

            case R.id.exbtn:

                alert_dialogbuilder = new AlertDialog.Builder(MainActivity.this);
                alert_dialogbuilder.setTitle(R.string.title);
                alert_dialogbuilder.setMessage(R.string.massage);
                alert_dialogbuilder.setIcon(R.drawable.question);
                alert_dialogbuilder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        finishAffinity();

                    }

                });
                alert_dialogbuilder.setNegativeButton("no", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        dialogInterface.cancel();
                    }
                });
                alert_dialogbuilder.setNeutralButton("cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        Toast.makeText(MainActivity.this, "you have clicked cancel button", Toast.LENGTH_SHORT).show();
                    }
                });

                AlertDialog alertDialog = alert_dialogbuilder.create();
                alertDialog.show();

            case R.id.record:
                Fragment fragment;
                fragment= new record();
                FragmentManager fm=getSupportFragmentManager();
                FragmentTransaction ft=fm.beginTransaction();
                ft.replace(R.id.fragment1,fragment);
                ft.commit();
        }
    }


}